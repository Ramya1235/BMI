import DashboardNav from "../components/DashboardNav";
import ConnectNav from "../components/Profile";



const Dashboard = () => {
    return (
        <>

            <div className="container-fluid p-4">
                <DashboardNav />
            </div>
            <div className="container-fluid  p-3">
                <ConnectNav />
            </div>



            
        </>
    );
};

export default Dashboard;