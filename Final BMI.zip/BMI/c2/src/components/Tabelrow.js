function Emp(props){
    return(
        <tr>
        
        <td>{props.name}</td>
        <td>{props.eid}</td>
        <td>{props.salary}</td>
        <td>{props.age}</td>
        
      </tr>
    )
}
export default Emp;
