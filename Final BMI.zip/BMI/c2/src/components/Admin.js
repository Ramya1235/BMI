import { getcal } from "../actions/auth";
import Tablerow from "./Tablerow";
import React, { useState, useEffect } from "react";


const Admin = () => {
    const [bmis, setBmis] = useState([]);
    useEffect(async () => {

        try {

            const data = await (await getcal()).data;

            setBmis(data);
            console.log(data);

        } catch (error) {
            console.log(error)

        }

    }, []);
    return (

        <div className="">
            <h1 className="">Admin Pannel</h1>
            <table className='table table-bordered table-primary'>

                <thead className='bs'>

                    <tr>

                        <th>Name</th>

                        <th>Height</th>

                        <th>Weight</th>

                        <th>BMI</th>
                    </tr>

                </thead>

                <tbody>

                    {bmis.map(bmi => {

                        return (

                            <Tablerow name={bmi.name} height={bmi.height} bmi={bmi.bmi}
                                mass={bmi.weight}
                            />

                        )

                    })}

                </tbody>

            </table>
        </div>

    )
}
export default Admin;